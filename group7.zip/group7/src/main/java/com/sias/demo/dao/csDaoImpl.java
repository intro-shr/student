package com.sias.demo.dao;

import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.csEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class csDaoImpl implements csDao {
    private Connection conn;
    private ResultSet res;
    private PreparedStatement pst;


    @Override
    public int savecs(csEntity entity) {
        String sql = "insert into cs (id,courseCode,courseName,courseDescription,startTime,endTime,createdAt,createdBy,location,department) values(id,?,?,?,?,?,?,?,?,?)";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i = 0;
        try {
            pst = conn.prepareStatement(sql);

            pst.setString(1, entity.getCourseCode());
            pst.setString(2, entity.getCourseName());
            pst.setString(3, entity.getCourseDescription());
            pst.setString(4, entity.getStartTime());
            pst.setString(5, entity.getEndTime());
            pst.setString(6, entity.getCreatedAt());
            pst.setString(7, entity.getCreatedBy());
            pst.setString(8, entity.getLocation());
            pst.setString(9, entity.getDepartment());
            i = pst.executeUpdate();


        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }


    public int updatecs (csEntity entity) {

        String sql = "update cs set courseCode=?,courseName=?,courseDescription=?,startTime=?,endTime=?,createdAt=?,createdBy=?,location=?,department=? where id=?";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        int i=0;


        try {
            pst=conn.prepareStatement(sql);

            pst.setString(1, entity.getCourseCode());
            pst.setString(2, entity.getCourseName());
            pst.setString(3, entity.getCourseDescription());
            pst.setString(4, entity.getStartTime());
            pst.setString(5, entity.getEndTime());
            pst.setString(6, entity.getCreatedAt());
            pst.setString(7, entity.getCreatedBy());
            pst.setString(8, entity.getLocation());
            pst.setString(9, entity.getDepartment());
            pst.setInt(10,entity.getId());

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }



    //查询单个属性所有值
    @Override
    public List<csEntity> selectALL() {
        String sql="select id,courseCode,courseName,courseDescription,startTime,endTime,createdAt,createdBy,location,department from cs";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        List<csEntity> list=new ArrayList<csEntity>();
        try {
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();

            while(res.next()){
                csEntity entity=new csEntity();
                entity.setId(res.getInt(1));
                entity.setCourseCode(res.getString(2));
                entity.setCourseName(res.getString(3));
                entity.setCourseDescription(res.getString(4));
                entity.setStartTime(res.getString(5));
                entity.setEndTime(res.getString(6));
                entity.setCreatedAt(res.getString(7));
                entity.setCreatedBy(res.getString(8));
                entity.setLocation(res.getString(9));
                entity.setDepartment(res.getString(10));
                list.add(entity);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public csEntity selectById(String id) {
        String sql="select  id,courseCode,courseName,courseDescription,startTime,endTime,createdAt,createdBy,location,department from cs where id=?";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
       csEntity entity=null;
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            res=pst.executeQuery();

            while(res.next()){
               entity=new csEntity();
               entity.setId(res.getInt(1));
               entity.setCourseCode(res.getString(2));
               entity.setCourseName(res.getString(3));
               entity.setCourseDescription(res.getString(4));
               entity.setStartTime(res.getString(5));
               entity.setEndTime(res.getString(6));
               entity.setCreatedAt(res.getString(7));
               entity.setCreatedBy(res.getString(8));
               entity.setLocation(res.getString(9));
               entity.setDepartment(res.getString(10));

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entity;
    }

    @Override
    public int deletecs(String id) {
        String sql=" delete from  cs  where  id=?";

        DBConnection db=new DBConnection();
        conn=db.getConnection();
        int i=0;

        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            i=pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }
}




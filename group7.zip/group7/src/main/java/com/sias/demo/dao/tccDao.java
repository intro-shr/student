package com.sias.demo.dao;

import com.sias.demo.entity.tccEntity;

import java.util.List;

public interface tccDao {
    int inserttcc(tccEntity entity);

    int updatetcc(tccEntity entity);

    List<tccEntity> selectALL();
    tccEntity selectById(String id);

    int deletetcc(String id);
}

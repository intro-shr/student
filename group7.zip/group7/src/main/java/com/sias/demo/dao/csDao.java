package com.sias.demo.dao;

import com.sias.demo.entity.csEntity;

import java.util.List;

public interface csDao {
    public int savecs(csEntity entity);
    public int updatecs(csEntity entity);
    List<csEntity> selectALL();
    csEntity selectById(String Id);
    public int deletecs(String id);
}

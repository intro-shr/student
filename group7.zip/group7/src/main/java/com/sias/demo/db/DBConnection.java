package com.sias.demo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private String usename="root";
    private String pwd ="123456";
    private String driver="com.mysql.cj.jdbc.Driver";
    private String url="jdbc:mysql://localhost:3306/group7?serverTimezone=GMT%2B8";
    private Connection connection;

    public DBConnection(){

        try {
            Class.forName(driver);
            connection= DriverManager.getConnection(url,usename,pwd);
        }catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public Connection getConnection() {
        return connection;
    }
}

package com.sias.demo.dao;

import com.sias.demo.entity.stuEntity;

import java.util.List;

public interface stuDao {

    int insertstu(stuEntity entity);

    int updatestu(stuEntity entity);

    List<stuEntity> selectALL();
    stuEntity selectById(String id);

    int deletesstu(String id);

}

package com.sias.demo.dao;


import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.tsEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class tsDaoImpl implements tsDao {
    private Connection conn;
    private ResultSet res;
    private PreparedStatement pst;

    @Override
    public int insertts(tsEntity entity) {
        String sql = "insert ts (id,instructorCode,name,education,biography,departmentName,status) values(id,?,?,?,?,?,?)";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i=0;

        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1,entity.getInstructorCode());
            pst.setString(2,entity.getName());
            pst.setString(3,entity.getEducation());
            pst.setString(4,entity.getBiography());
            pst.setString(5,entity.getDepartmentName());
            pst.setString(6,entity.getStatus());
            i = pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }


    @Override
    public int updatets(tsEntity entity) {
        String sql = "update ts set instructorCode=?,name=?,education=?,biography=?,departmentName=?,status=? where id=?";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i=0;

        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1,entity.getInstructorCode());
            pst.setString(2,entity.getName());
            pst.setString(3,entity.getEducation());
            pst.setString(4,entity.getBiography());
            pst.setString(5,entity.getDepartmentName());
            pst.setString(6,entity.getStatus());
            pst.setInt(7,entity.getId());
            i = pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }

    @Override
    public List<tsEntity> selectALL() {

        String sql = "select id,instructorCode,name,education,biography,departmentName,status from ts";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
       List<tsEntity> list=new ArrayList<tsEntity>();
        try {
            pst = conn.prepareStatement(sql);
            res= pst.executeQuery();


            while (res.next()) {
                tsEntity entity = new tsEntity();
                entity.setId(res.getInt(1));
                entity.setInstructorCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setEducation(res.getString(4));
                entity.setBiography(res.getString(5));
                entity.setDepartmentName(res.getString(6));
                entity.setStatus(res.getString(7));
                list.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public tsEntity selectById(String id) {
        String sql = "select id,instructorCode,name,education,biography,departmentName,status from ts where id=?";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        tsEntity entity = null;
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            res = pst.executeQuery();

            while (res.next()) {
                entity=new tsEntity();
                entity.setId(res.getInt(1));
                entity.setInstructorCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setEducation(res.getString(4));
                entity.setBiography(res.getString(5));
                entity.setDepartmentName(res.getString(6));
                entity.setStatus(res.getString(7));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entity;
    }

    @Override
    public int deletets(String id) {

        String sql="delete from ts where id=?";
        DBConnection db = new DBConnection();
        conn= db.getConnection();
        int i=0;
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            i=pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }
}

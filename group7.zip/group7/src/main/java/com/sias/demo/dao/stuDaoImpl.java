package com.sias.demo.dao;

import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.stuEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class stuDaoImpl implements stuDao{

    private Connection conn;
    private ResultSet res;
    private PreparedStatement pst;


    @Override
    public int insertstu(stuEntity entity){
        String sql = "insert into stu (id,employeeCode,name,idCardNumber,address,contactNumber,department) values(id,?,?,?,?,?,?)";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i = 0;
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1,entity.getEmployeeCode());
            pst.setString(2,entity.getName());
            pst.setString(3,entity.getIdCardNumber());
            pst.setString(4,entity.getAddress());
            pst.setString(5,entity.getContactNumber());
            pst.setString(6,entity.getDepartment());
            i = pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }

    @Override
    public int updatestu(stuEntity entity) {

        String sql = "update stu set employeeCode=?,name=?,idCardNumber=?,address=?,contactNumber=?,department=? where id=?";
        DBConnection db = new DBConnection();
        conn= db.getConnection();
        int i=0;

        try {
            pst=conn.prepareStatement(sql);

           pst.setString(1,entity.getEmployeeCode());
           pst.setString(2,entity.getName());
           pst.setString(3,entity.getIdCardNumber());
           pst.setString(4,entity.getAddress());
           pst.setString(5,entity.getContactNumber());
           pst.setString(6,entity.getDepartment());
           pst.setInt(7,entity.getId());

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }

    @Override
    public List<stuEntity> selectALL() {

        String sql="select  id,employeeCode,name,idCardNumber,address,contactNumber,department from stu";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        List<stuEntity> list=new ArrayList<stuEntity>();

        try {
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();

            while(res.next()){
                stuEntity entity = new stuEntity();

                entity=new stuEntity();
                entity.setId(res.getInt(1));
                entity.setEmployeeCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setIdCardNumber(res.getString(4));
                entity.setAddress(res.getString(5));
                entity.setContactNumber(res.getString(6));
                entity.setDepartment(res.getString(7));
                list.add(entity);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }


    @Override
    public stuEntity selectById(String id) {

        String sql="select  id,employeeCode,name,idCardNumber,address,contactNumber,department from stu where id=?";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        stuEntity entity=null;
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            res=pst.executeQuery();

            while(res.next()){
                entity=new stuEntity();
                entity.setId(res.getInt(1));
                entity.setEmployeeCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setIdCardNumber(res.getString(4));
                entity.setAddress(res.getString(5));
                entity.setContactNumber(res.getString(6));
                entity.setDepartment(res.getString(7));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entity;
    }

    @Override
    public int deletesstu(String id) {
        String sql = "delete from stu where id=?";
        DBConnection db = new DBConnection();
        conn= db.getConnection();
        int i=0;

        try {
            pst=conn.prepareStatement(sql);

            pst.setString(1,id);

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }
}

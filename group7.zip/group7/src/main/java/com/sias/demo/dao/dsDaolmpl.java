package com.sias.demo.dao;

import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.dsEntity;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class dsDaolmpl implements dsDao{
    private Connection conn;
    private ResultSet res;
    private PreparedStatement pst;


    @Override
    public int insertds(dsEntity entity){
        String sql = "insert into ds (id,departmentCode,name,city) values(id,?,?,?)";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i = 0;
        try {
            pst = conn.prepareStatement(sql);
           pst.setString(1,entity.getDepartmentCode());
           pst.setString(2,entity.getName());
           pst.setString(3,entity.getCity());
            i = pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }

    @Override
    public int updateds(dsEntity entity) {

        String sql = "update ds set departmentCode=?,name=?,city=? where id=?";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        int i=0;

        try {
            pst=conn.prepareStatement(sql);

            pst.setString(1,entity.getDepartmentCode());
            pst.setString(2, entity.getName());
            pst.setString(3,entity.getCity());
            pst.setInt(4,entity.getId());

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }


    @Override
    public List<dsEntity> selectALL() {
        String sql="select id,departmentCode,name,city from ds";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        List<dsEntity> list=new ArrayList<dsEntity>();
        try {
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();

            while(res.next()){
                dsEntity entity = new dsEntity();
                entity.setId(res.getInt(1));
                entity.setDepartmentCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setCity(res.getString(4));
                list.add(entity);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    @Override
    public dsEntity selectById(String id) {
        String sql="select  id,departmentCode,name,city from ds where id=?";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        dsEntity entity=null;
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            res=pst.executeQuery();

            while(res.next()){
                entity=new dsEntity();
                entity.setId(res.getInt(1));
                entity.setDepartmentCode(res.getString(2));
                entity.setName(res.getString(3));
                entity.setCity(res.getString(4));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return entity;
    }

    @Override
    public int deletesds(String id){
        String sql=" delete from  ds  where  id=?";

        DBConnection db=new DBConnection();
        conn=db.getConnection();
        int i=0;

        try {
            pst=conn.prepareStatement(sql);

            pst.setString(1,id);

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }
}

package com.sias.demo.dao;

import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.tccEntity;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class tccDaoImpl implements tccDao{
    private Connection conn;
    private ResultSet res;
    private PreparedStatement pst;


    @Override
    public int inserttcc(tccEntity entity) {
        String sql = "insert tcc (id,instructorCode,courseCode) values(id,?,?)";
        DBConnection db = new DBConnection();
        conn = db.getConnection();
        int i=0;

        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1,entity.getInstructorCode());
            pst.setString(2,entity.getCourseCode());
            i = pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null && !conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return i;
    }

    @Override
    public int updatetcc(tccEntity entity) {
        String sql = "update tcc set instructorCode=?,courseCode=? where id = ? ";
        DBConnection db = new DBConnection();
        conn= db.getConnection();
        int i = 0;

        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,entity.getInstructorCode());
            pst.setString(2,entity.getCourseCode());
            pst.setInt(3,entity.getId());

            i=pst.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }


    @Override
    public List<tccEntity> selectALL() {
        String sql="select id,instructorCode,courseCode from tcc";
        DBConnection db=new DBConnection();
        conn=db.getConnection();
        List<tccEntity> list=new ArrayList<tccEntity>();
        try {
            pst=conn.prepareStatement(sql);
            res=pst.executeQuery();

            while(res.next()){
                tccEntity entity=new tccEntity();
                entity.setId(res.getInt(1));
                entity.setInstructorCode(res.getString(2));
                entity.setCourseCode(res.getString(3));
                list.add(entity);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return list;
    }


    @Override
    public tccEntity selectById (String id){
            String sql = "select  id,instructorCode,courseCode from tcc where id=?";
            DBConnection db = new DBConnection();
            conn = db.getConnection();
            tccEntity entity = null;
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, id);
                res = pst.executeQuery();

                while (res.next()) {
                    entity = new tccEntity();
                   entity.setId(res.getInt(1));
                    entity.setInstructorCode(res.getString(2));
                    entity.setCourseCode(res.getString(3));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (conn != null && !conn.isClosed()) {
                        conn.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            return entity;
        }

    @Override
    public int deletetcc(String id) {

        String sql="delete from tcc where id=?";
        DBConnection db = new DBConnection();
        conn= db.getConnection();
        int i=0;
        try {
            pst=conn.prepareStatement(sql);
            pst.setString(1,id);
            i=pst.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                if(conn!=null&&!conn.isClosed()){
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return i;
    }
}

package com.sias.demo.dao;

import com.sias.demo.entity.tsEntity;

import java.util.List;

public interface tsDao {
    int insertts(tsEntity entity);

    int updatets(tsEntity entity);

    List<tsEntity> selectALL();

    tsEntity selectById(String id);
    int deletets(String id);

}

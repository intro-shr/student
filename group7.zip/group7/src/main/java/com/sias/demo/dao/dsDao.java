package com.sias.demo.dao;
import com.sias.demo.entity.dsEntity;

import java.util.List;

public interface dsDao {
    public int insertds(dsEntity entity);

    public int updateds(dsEntity entity);
    List<dsEntity> selectALL();
    dsEntity selectById(String id);

    int deletesds(String id);
}

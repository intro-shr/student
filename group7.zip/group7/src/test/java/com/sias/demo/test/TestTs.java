package com.sias.demo.test;

import com.sias.demo.dao.tsDaoImpl;
import com.sias.demo.entity.tsEntity;
import org.junit.Test;

import java.util.List;

public class TestTs {
    @Test
    public void testInset(){
        tsDaoImpl dao = new tsDaoImpl();
        tsEntity en = new tsEntity();
        en.setInstructorCode("200002222");
        en.setName("王四");
        en.setEducation("博士");
        en.setBiography("姓名王三学历研究生");
        en.setDepartmentName("管理部");
        en.setStatus("内部");
        int i = dao.insertts(en);
        System.out.println(i);
    }

    @Test
    public void testUpdate(){
        tsDaoImpl dao = new tsDaoImpl();
        tsEntity en = dao.selectById("1");
        en.setName("王二更改测试");
        int i = dao.updatets(en);
        System.out.println(i);
    }

    @Test
    public void testSelectALL(){
        tsDaoImpl dao=new tsDaoImpl();
        List<tsEntity> list = dao.selectALL();
        if(list!=null){
            for(tsEntity e:list){
                //查询e.属性的单个值
                System.out.println(e.getName());
            }
        }
    }

    @Test
    public void deletets(){
        tsDaoImpl dao = new tsDaoImpl();
        tsEntity en = new tsEntity();
        int i = dao.deletets("3");
        if (i==1){
            System.out.println("删除成功");
        }

    }




}

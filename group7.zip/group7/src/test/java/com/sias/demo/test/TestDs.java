package com.sias.demo.test;

import com.sias.demo.entity.dsEntity;
import com.sias.demo.dao.dsDaolmpl;
import com.sias.demo.db.DBConnection;
import org.junit.Test;

import java.sql.Connection;
import java.util.List;

public class TestDs {
    @Test
    public void testConnection(){
        DBConnection db=new DBConnection();
        Connection connection=db.getConnection();
        System.out.println(connection==null);
    }

    @Test
    public void testinsert(){
        dsDaolmpl dao = new dsDaolmpl();
        dsEntity en = new dsEntity();

        en.setDepartmentCode("C0103");
        en.setName("汉语学院03");
        en.setCity("北京03");

        int i = dao.insertds(en);//定义改变的行数
        System.out.println(i);//输出改变的行数
    }

    @Test
    public void testupdate(){
        dsDaolmpl dao = new dsDaolmpl();
        dsEntity en = dao.selectById("3");
        en.setName("汉语学院03更改测试");
        int i=dao.updateds(en);
        System.out.println(i);
    }

    @Test
    public void testSelectALL(){
        dsDaolmpl dao = new dsDaolmpl();
        List<dsEntity> list= dao.selectALL();

        if (list!=null){
            for(dsEntity e:list){

                System.out.println(e.getName());//查询名字这一属性的所有值
            }
        }
    }

    @Test
    public void deletesds(){
        dsDaolmpl dao = new dsDaolmpl();
        dsEntity en = new dsEntity();
        int i = dao.deletesds("1");
            if (i==1){
                System.out.println("删除成功");
            }
    }
}


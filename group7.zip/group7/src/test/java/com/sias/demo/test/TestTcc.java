package com.sias.demo.test;

import com.sias.demo.dao.tccDaoImpl;
import com.sias.demo.entity.tccEntity;
import org.junit.Test;

import java.util.List;

public class TestTcc {
    @Test
    public void testInset(){
        tccDaoImpl dao = new tccDaoImpl();
        tccEntity en = new tccEntity();
        en.setInstructorCode("100003");
        en.setCourseCode("003");
        int i = dao.inserttcc(en);
        System.out.println(i);
    }


    @Test
    public void testUpdate(){
        tccDaoImpl dao = new tccDaoImpl();
        tccEntity en = dao.selectById("1");
        en.setInstructorCode("100001000");
        int i = dao.updatetcc(en);
        System.out.println(i);
    }
    @Test
    public void testSelectALL(){
        tccDaoImpl dao=new tccDaoImpl();
        List<tccEntity> list = dao.selectALL();
        if(list!=null){
            for(tccEntity e:list){
                //查询e.属性的单个值
                System.out.println(e.getInstructorCode());
            }
        }
    }

    @Test
    public void deletetcc(){
        tccDaoImpl dao = new tccDaoImpl();
        tccEntity en = new tccEntity();
        int i = dao.deletetcc("3");
                if (i==1){
                    System.out.println("删除成功");
                }

    }
}


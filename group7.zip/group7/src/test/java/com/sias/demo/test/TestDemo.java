package com.sias.demo.test;

import com.sias.demo.dao.csDaoImpl;
import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.csEntity;
import org.junit.Test;

import java.sql.Connection;
import java.util.List;

public class TestDemo {
    @Test
    public void testConnection(){
        DBConnection db=new DBConnection();
        Connection connection=db.getConnection();
        System.out.println(connection==null);
    }
    @Test
    public void testSave(){
        csDaoImpl dao = new csDaoImpl();
        csEntity en = new csEntity();

        en.setCourseCode("1");
        en.setCourseName("语文");
        en.setCourseDescription("诗词歌赋");
        en.setStartTime("2024.10.01");
        en.setEndTime("2024.12.01");
        en.setCreatedAt("2024.9.01");
        en.setCreatedBy("张三");
        en.setLocation("致远楼");
        en.setDepartment("汉语学院");
        int i = dao.savecs(en);
        System.out.println(i);
    }


    @Test
    public void testUpdate(){
        csDaoImpl dao = new csDaoImpl();
        csEntity en = dao.selectById("1");
        en.setCourseName("语文更改测试");
        int i= dao.updatecs(en);
        System.out.println(i);

    }
    @Test
    public void testSelectALL(){
        csDaoImpl dao=new csDaoImpl();
        List<csEntity> list = dao.selectALL();

        if(list!=null){
            for(csEntity e:list){
                //查询e.属性的单个值
                System.out.println(e.getEndTime());
            }
        }
    }
    @Test
    public void deletecs(){

        csDaoImpl dao = new csDaoImpl();
        csEntity en = new csEntity();
        int i = dao.deletecs("2");
                if(i==1){
                    System.out.println("删除成功");
                }
    }
}

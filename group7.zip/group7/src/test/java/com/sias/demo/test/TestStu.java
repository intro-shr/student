package com.sias.demo.test;

import com.sias.demo.dao.stuDaoImpl;
import com.sias.demo.db.DBConnection;
import com.sias.demo.entity.stuEntity;
import org.junit.Test;

import java.sql.Connection;
import java.util.List;

public class TestStu {
    @Test
    public void testConnection(){
        DBConnection db=new DBConnection();
        Connection connection=db.getConnection();
        System.out.println(connection==null);
    }
    @Test
    public void testInsert(){
        stuDaoImpl dao = new stuDaoImpl();
        stuEntity en = new stuEntity();
        en.setEmployeeCode("100001022");
        en.setName("李四02");
        en.setIdCardNumber("411624002");
        en.setAddress("郑州02");
        en.setContactNumber("17389233423002");
        en.setDepartment("管理学院002");
        int i = dao.insertstu(en);
        System.out.println(i);
    }

    @Test
    public void testUpdate(){
        stuDaoImpl dao = new stuDaoImpl();
        stuEntity en = dao.selectById("2");
        en.setName("李四02更改测试");
        int i = dao.updatestu(en);
        System.out.println(i);
    }

    @Test
    public void testSelectALL(){
        stuDaoImpl dao = new stuDaoImpl();
        List<stuEntity> list = dao.selectALL();

        if (list!=null){
            for (stuEntity e:list){

                System.out.println(e.getName());
            }
        }
    }

    @Test
    public void deletesstu(){
        stuDaoImpl dao = new stuDaoImpl();
        stuEntity en = new stuEntity();

        int i = dao.deletesstu("2");
        if (i==1){
            System.out.println("删除成功");
        }
    }

}
